
/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html","./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          navy: "#0b1a3f",
          cream: "#fbf3ea",
          gold: "#c99a2e",
          goldDark: "#a07a24",
        }
      },
      fontFamily: {
        display: ['"Playfair Display"', 'serif'],
        body: ['"Inter"', 'system-ui', 'sans-serif']
      },
      boxShadow: {
        card: "0 8px 24px rgba(11, 26, 63, 0.08)"
      }
    },
  },
  plugins: [],
}
