
export default function Footer(){
  return (
    <footer className="mt-16 bg-brand-navy text-brand-cream">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <div className="flex items-center gap-3">
              <img src="/assets/logo-light.svg" alt="SBC by Shweta" className="h-9"/>
            </div>
            <p className="mt-3 text-sm text-brand-cream/80">
              Handcrafted devotion wear and elegant sarees delivered with care.
            </p>
          </div>
          <div className="md:text-right">
            <p className="font-medium">100% Secure Payments</p>
            <div className="mt-3 flex md:justify-end gap-3 opacity-90">
              <span className="px-3 py-1 rounded bg-brand-cream text-brand-navy text-xs">VISA</span>
              <span className="px-3 py-1 rounded bg-brand-cream text-brand-navy text-xs">MasterCard</span>
              <span className="px-3 py-1 rounded bg-brand-cream text-brand-navy text-xs">RuPay</span>
              <span className="px-3 py-1 rounded bg-brand-cream text-brand-navy text-xs">COD</span>
            </div>
          </div>
        </div>
        <div className="mt-8 border-t border-white/10 pt-4 text-xs text-brand-cream/70">
          © {new Date().getFullYear()} SBC by Shweta. All rights reserved.
        </div>
      </div>
    </footer>
  )
}
