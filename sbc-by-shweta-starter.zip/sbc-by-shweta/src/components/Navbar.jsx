
import { Link, NavLink } from 'react-router-dom'
import useCart from '../store/cartStore'

const active = 'text-brand-gold'
const base = 'hover:text-brand-gold transition-colors'

export default function Navbar(){
  const items = useCart(s=>s.items)
  const qty = items.reduce((n,i)=>n+i.qty,0)

  return (
    <header className="bg-white shadow sticky top-0 z-40">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <img src="/assets/logo-dark.svg" alt="SBC by Shweta" className="h-9"/>
        </Link>

        <nav className="hidden md:flex items-center gap-6 text-sm">
          <NavLink to="/" className={({isActive})=> isActive?active:base}>Home</NavLink>
          <NavLink to="/kanha-ji-dress" className={({isActive})=> isActive?active:base}>Kanha Ji Dress</NavLink>
          <NavLink to="/sarees" className={({isActive})=> isActive?active:base}>Sarees</NavLink>
          <NavLink to="/other-products" className={({isActive})=> isActive?active:base}>Other Products</NavLink>
        </nav>

        <div className="flex items-center gap-3">
          <Link to="/login" className="hidden sm:inline text-sm text-brand-navy hover:text-brand-gold">Login</Link>
          <Link to="/cart" className="relative">
            <span className="inline-flex h-9 px-3 items-center rounded-full border border-brand-gold text-brand-navy hover:bg-brand-gold hover:text-white transition">Cart</span>
            {qty>0 && (
              <span className="absolute -right-2 -top-2 text-xs bg-brand-gold text-white rounded-full px-1.5 py-0.5">{qty}</span>
            )}
          </Link>
        </div>
      </div>
    </header>
  )
}
