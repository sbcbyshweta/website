
const feats = [
  { title: 'Premium Quality' },
  { title: 'Handcrafted' },
  { title: 'Trusted Delivery' },
]

export default function FeatureBar(){
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-8">
      {feats.map((f,i)=>(
        <div key={i} className="rounded-xl bg-white border border-brand-gold/20 p-4 text-center shadow-card">
          <p className="font-medium text-brand-navy">{f.title}</p>
        </div>
      ))}
    </div>
  )
}
