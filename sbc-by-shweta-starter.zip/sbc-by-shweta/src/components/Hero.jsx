
import { Link } from 'react-router-dom'

export default function Hero(){
  return (
    <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-brand-cream to-white border border-brand-gold/20 mt-6">
      <div className="px-8 py-16 md:py-20 md:px-12">
        <h1 className="font-display text-3xl md:text-5xl text-brand-navy leading-tight">
          Divine Fashion for <span className="text-brand-gold">Kanha Ji & You</span>
        </h1>
        <p className="mt-4 max-w-2xl text-brand-navy/80">
          Explore exquisite, handcrafted attire made with devotion, elegance, and superior craftsmanship.
        </p>
        <div className="mt-8">
          <Link to="/kanha-ji-dress" className="inline-flex items-center gap-2 bg-brand-gold text-white px-6 py-3 rounded-full shadow hover:bg-brand-goldDark transition">
            Shop Now
          </Link>
        </div>
      </div>
    </section>
  )
}
